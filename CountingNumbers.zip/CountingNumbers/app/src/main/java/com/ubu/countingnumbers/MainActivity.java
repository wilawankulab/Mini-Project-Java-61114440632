package com.ubu.countingnumbers;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {


    private ImageView startgame;
    MediaPlayer mysound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mysound = MediaPlayer.create(this,R.raw.n);
        mysound.start();
        mysound.setLooping(true);

        startgame = (ImageView) findViewById(R.id.ma1);

        startgame.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                Intent j = new Intent(MainActivity.this, LanguageActivity.class);
                startActivity(j);
                mysound.stop();

            }
        });


    }


}

