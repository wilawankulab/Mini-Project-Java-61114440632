package com.ubu.countingnumbers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Number2 extends AppCompatActivity {
    MediaPlayer k1;
    MediaPlayer k2;
    MediaPlayer k3;
    MediaPlayer k4;
    MediaPlayer k5;
    MediaPlayer k6;
    MediaPlayer k7;
    MediaPlayer k8;
    MediaPlayer k9;
    MediaPlayer k10;
    private ImageView BlackHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number2);

        BlackHome = (ImageView) findViewById(R.id.BlackHome);

        BlackHome.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                finish();

            }
        });

        k1 = MediaPlayer.create(Number2.this, R.raw.k1);
        k2 = MediaPlayer.create(Number2.this, R.raw.k2);
        k3 = MediaPlayer.create(Number2.this, R.raw.k3);
        k4 = MediaPlayer.create(Number2.this, R.raw.k4);
        k5 = MediaPlayer.create(Number2.this, R.raw.k5);
        k6 = MediaPlayer.create(Number2.this, R.raw.k6);
        k7 = MediaPlayer.create(Number2.this, R.raw.k7);
        k8 = MediaPlayer.create(Number2.this, R.raw.k8);
        k9 = MediaPlayer.create(Number2.this, R.raw.k9);
        k10 = MediaPlayer.create(Number2.this, R.raw.k10);

    }

    public void cnumber1(View view) {
        k1.start();
    }

    public void cnumber2(View view) {
        k2.start();
    }

    public void cnumber3(View view) {
        k3.start();
    }

    public void cnumber4(View view) {
        k4.start();
    }

    public void cnumber5(View view) {
        k5.start();
    }

    public void cnumber6(View view) {
        k6.start();
    }

    public void cnumber7(View view) {
        k7.start();
    }

    public void cnumber8(View view) {
        k8.start();
    }

    public void cnumber9(View view) {
        k9.start();
    }

    public void cnumber10(View view) {
        k10.start();
    }
}


