package com.ubu.countingnumbers;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;


public class LanguageActivity extends AppCompatActivity {
    private ImageView chinese;
    private ImageView Korea;
    private ImageView Japanese;
    private ImageView Thailand;
    private ImageView England;
    private ImageView BlackHome;

    MediaPlayer chinese1;
    MediaPlayer Korea1;
    MediaPlayer Japanese1;
    MediaPlayer Thailand1;
    MediaPlayer England1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        chinese1 = MediaPlayer.create(this,R.raw.c);
        Korea1 =  MediaPlayer.create(this,R.raw.k);
        Japanese1 =  MediaPlayer.create(this,R.raw.y);
        Thailand1 =  MediaPlayer.create(this,R.raw.t);
        England1=  MediaPlayer.create(this,R.raw.o);


        chinese = (ImageView) findViewById(R.id.chinese);
        Korea = (ImageView) findViewById(R.id.Korea);
        Japanese = (ImageView) findViewById(R.id.Japanese) ;
        Thailand = (ImageView) findViewById(R.id.Thailand);
        England = (ImageView) findViewById(R.id.England);


        BlackHome = (ImageView) findViewById(R.id.BlackHome);

        BlackHome.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                finish();

            }
        });

        chinese.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(LanguageActivity.this,Number1.class);
                startActivity(j);
                chinese1.start();
            }
        });

        Korea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent l = new Intent(LanguageActivity.this, Number2.class);
                startActivity(l);
                Korea1.start();
            }
        });

        Japanese.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent b = new Intent(LanguageActivity.this, Number3.class);
                startActivity(b);
                Japanese1.start();
            }
        });

        Thailand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent c = new Intent(LanguageActivity.this, Number4.class);
                startActivity(c);
                Thailand1.start();
            }
        });

        England.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent z = new Intent(LanguageActivity.this, Number5.class);
                startActivity(z);
                England1.start();
            }
        });


    }
}