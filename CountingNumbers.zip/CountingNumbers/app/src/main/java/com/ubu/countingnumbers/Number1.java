package com.ubu.countingnumbers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Number1 extends AppCompatActivity {
    MediaPlayer j1;
    MediaPlayer j2;
    MediaPlayer j3;
    MediaPlayer j4;
    MediaPlayer j5;
    MediaPlayer j6;
    MediaPlayer j7;
    MediaPlayer j8;
    MediaPlayer j9;
    MediaPlayer j10;
    private ImageView BlackHome;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number1);

        BlackHome = (ImageView) findViewById(R.id.BlackHome);

        BlackHome.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                finish();

            }
        });


        j1 = MediaPlayer.create(Number1.this, R.raw.j1);
        j2 = MediaPlayer.create(Number1.this, R.raw.j2);
        j3 = MediaPlayer.create(Number1.this, R.raw.j3);
        j4 = MediaPlayer.create(Number1.this, R.raw.j4);
        j5 = MediaPlayer.create(Number1.this, R.raw.j5);
        j6 = MediaPlayer.create(Number1.this, R.raw.j6);
        j7 = MediaPlayer.create(Number1.this, R.raw.j7);
        j8 = MediaPlayer.create(Number1.this, R.raw.j8);
        j9 = MediaPlayer.create(Number1.this, R.raw.j9);
        j10 = MediaPlayer.create(Number1.this, R.raw.j10);

    }

    public void cnumber1(View view) {
        j1.start(); }

    public void cnumber2(View view) {
        j2.start();
    }

    public void cnumber3(View view) {
        j3.start();
    }

    public void cnumber4(View view) {
        j4.start();
    }

    public void cnumber5(View view) { j5.start(); }

    public void cnumber6(View view) {
        j6.start();
    }

    public void cnumber7(View view) {
        j7.start();
    }

    public void cnumber8(View view) {
        j8.start();
    }

    public void cnumber9(View view) {
        j9.start();
    }

    public void cnumber10(View view) {
        j10.start();
    }
}