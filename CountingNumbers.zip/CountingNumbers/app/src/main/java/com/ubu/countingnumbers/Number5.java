package com.ubu.countingnumbers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Number5 extends AppCompatActivity {
    MediaPlayer o1;
    MediaPlayer o2;
    MediaPlayer o3;
    MediaPlayer o4;
    MediaPlayer o5;
    MediaPlayer o6;
    MediaPlayer o7;
    MediaPlayer o8;
    MediaPlayer o9;
    MediaPlayer o10;
    private ImageView BlackHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number5);

        BlackHome = (ImageView) findViewById(R.id.BlackHome);

        BlackHome.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                finish();

            }
        });

        o1 = MediaPlayer.create(Number5.this, R.raw.o1);
        o2 = MediaPlayer.create(Number5.this, R.raw.o2);
        o3 = MediaPlayer.create(Number5.this, R.raw.o3);
        o4 = MediaPlayer.create(Number5.this, R.raw.o4);
        o5 = MediaPlayer.create(Number5.this, R.raw.o5);
        o6 = MediaPlayer.create(Number5.this, R.raw.o6);
        o7 = MediaPlayer.create(Number5.this, R.raw.o7);
        o8 = MediaPlayer.create(Number5.this, R.raw.o8);
        o9 = MediaPlayer.create(Number5.this, R.raw.o9);
        o10 = MediaPlayer.create(Number5.this, R.raw.o10);

    }

    public void cnumber1(View view) {
        o1.start();
    }

    public void cnumber2(View view) {
        o2.start();
    }

    public void cnumber3(View view) {
        o3.start();
    }

    public void cnumber4(View view) {
        o4.start();
    }

    public void cnumber5(View view) {
        o5.start();
    }

    public void cnumber6(View view) {
        o6.start();
    }

    public void cnumber7(View view) {
        o7.start();
    }

    public void cnumber8(View view) {
        o8.start();
    }

    public void cnumber9(View view) {
        o9.start();
    }

    public void cnumber10(View view) {
        o10.start();
    }


}
