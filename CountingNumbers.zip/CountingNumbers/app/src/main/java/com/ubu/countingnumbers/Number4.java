package com.ubu.countingnumbers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Number4 extends AppCompatActivity {
    MediaPlayer t1;
    MediaPlayer t2;
    MediaPlayer t3;
    MediaPlayer t4;
    MediaPlayer t5;
    MediaPlayer t6;
    MediaPlayer t7;
    MediaPlayer t8;
    MediaPlayer t9;
    MediaPlayer t10;
    private ImageView BlackHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number4);

        BlackHome = (ImageView) findViewById(R.id.BlackHome);
        BlackHome.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                finish();

            }
        });

        t1 = MediaPlayer.create(Number4.this, R.raw.t1);
        t2 = MediaPlayer.create(Number4.this, R.raw.t2);
        t3 = MediaPlayer.create(Number4.this, R.raw.t3);
        t4 = MediaPlayer.create(Number4.this, R.raw.t4);
        t5 = MediaPlayer.create(Number4.this, R.raw.t5);
        t6 = MediaPlayer.create(Number4.this, R.raw.t6);
        t7 = MediaPlayer.create(Number4.this, R.raw.t7);
        t8 = MediaPlayer.create(Number4.this, R.raw.t8);
        t9 = MediaPlayer.create(Number4.this, R.raw.t9);
        t10 = MediaPlayer.create(Number4.this, R.raw.t10);

    }

    public void cnumber1(View view) {
        t1.start();

    }

    public void cnumber2(View view) {
        t2.start();

    }

    public void cnumber3(View view) {
        t3.start();
    }

    public void cnumber4(View view) {
        t4.start();
    }

    public void cnumber5(View view) {
        t5.start();
    }

    public void cnumber6(View view) {
        t6.start();
    }

    public void cnumber7(View view) {
        t7.start();
    }

    public void cnumber8(View view) {
        t8.start();
    }

    public void cnumber9(View view) {
        t9.start();
    }

    public void cnumber10(View view) {
        t10.start();
    }

}
