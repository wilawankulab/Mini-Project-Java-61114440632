package com.ubu.countingnumbers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Number3 extends AppCompatActivity {
    MediaPlayer y1;
    MediaPlayer y2;
    MediaPlayer y3;
    MediaPlayer y4;
    MediaPlayer y5;
    MediaPlayer y6;
    MediaPlayer y7;
    MediaPlayer y8;
    MediaPlayer y9;
    MediaPlayer y10;
    private ImageView BlackHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number3);

        BlackHome = (ImageView) findViewById(R.id.BlackHome);

        BlackHome.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                finish();

            }
        });

        y1 = MediaPlayer.create(Number3.this, R.raw.y1);
        y2 = MediaPlayer.create(Number3.this, R.raw.y2);
        y3 = MediaPlayer.create(Number3.this, R.raw.y3);
        y4 = MediaPlayer.create(Number3.this, R.raw.y4);
        y5 = MediaPlayer.create(Number3.this, R.raw.y5);
        y6 = MediaPlayer.create(Number3.this, R.raw.y6);
        y7 = MediaPlayer.create(Number3.this, R.raw.y7);
        y8 = MediaPlayer.create(Number3.this, R.raw.y8);
        y9 = MediaPlayer.create(Number3.this, R.raw.y9);
        y10 = MediaPlayer.create(Number3.this, R.raw.y10);

    }

    public void cnumber1(View view) {
        y1.start();
    }

    public void cnumber2(View view) {
        y2.start();
    }

    public void cnumber3(View view) {
        y3.start();
    }

    public void cnumber4(View view) {
        y4.start();
    }

    public void cnumber5(View view) {
        y5.start();
    }

    public void cnumber6(View view) {
        y6.start();
    }

    public void cnumber7(View view) {
        y7.start();
    }

    public void cnumber8(View view) {
        y8.start();
    }

    public void cnumber9(View view) {
        y9.start();
    }

    public void cnumber10(View view) {
        y10.start();
    }
    }

